import sys
import os

_addon_root = os.path.dirname(os.path.abspath(__file__))
_lib_path = os.path.join(_addon_root, 'lib')
for _p in (_lib_path, _addon_root):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import threading
import socket
import subprocess
import re
from random import randint

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

from lib.pyftpdlib.authorizers import DummyAuthorizer
from lib.pyftpdlib.handlers import FTPHandler
from lib.pyftpdlib.servers import FTPServer

import smb_server as smb_mod
import variables
import utils

ADDON_ID = 'plugin.program.ftp1'
addon = xbmcaddon.Addon(ADDON_ID)

_WIN = xbmcgui.Window(10000)

_running_server = None
_running_smb    = None

def _svc_set(key, value):
    _WIN.setProperty('FtpSvc_' + key, str(value))

def _svc_get(key):
    return _WIN.getProperty('FtpSvc_' + key)

def _svc_clear():
    for k in ('Started', 'Port', 'Localhost', 'SmbStarted', 'SmbShare', 'SmbPort'):
        _WIN.clearProperty('FtpSvc_' + k)
    i = 0
    while _WIN.getProperty('FtpSvc_LocalIP%d' % i):
        _WIN.clearProperty('FtpSvc_LocalIP%d' % i)
        i += 1

def _get_smb_settings():
    enabled   = addon.getSetting('smb_enabled')  == 'true'
    autostart = addon.getSetting('smb_autostart') == 'true'
    share     = addon.getSetting('smb_share') or 'KODI'
    try:
        port = int(addon.getSetting('smb_port') or '4455')
    except ValueError:
        port = 4455
    anonymous = addon.getSetting('smb_anonymous') != 'false'
    username  = addon.getSetting('smb_user') or 'kodi'
    password  = addon.getSetting('smb_password') or 'kodi'
    return enabled, share, port, autostart, anonymous, username, password

def getLocalIP():
    platform = variables.getPlatformName()
    custom_server  = addon.getSetting('servery')
    custom_enabled = addon.getSetting('serverx') == 'true'
    if custom_enabled and custom_server:
        addon.setSetting('onlineserver', custom_server)
        return [custom_server]
    try:
        if platform in ('android', 'vavoo'):
            ip_app = '/system/bin/ip'
        elif platform == 'linux':
            ip_app = '/sbin/ip'
        else:
            ip_app = None
        if ip_app:
            ips = subprocess.check_output([ip_app, 'addr'], timeout=3).decode('utf-8', errors='replace')
            ips = re.findall(r'inet ([^/]+)', ips)
            ips = [y.strip() for y in ips if y.strip() and not y.strip().startswith('127.')]
        elif platform in ('win32', 'ios', 'osx'):
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(('1.2.3.4', 80))
                ips = [s.getsockname()[0]]
            finally:
                s.close()
        else:
            ips = []
        if ips:
            addon.setSetting('onlineserver', ips[0])
            return ips
    except Exception as e:
        xbmc.log('getLocalIP failed: %s' % e, xbmc.LOGWARNING)
    lan = xbmc.getInfoLabel('Network.IPAddress')
    counter = 0
    while counter < 20 and '.' not in lan:
        xbmc.sleep(200)
        lan = xbmc.getInfoLabel('Network.IPAddress')
        counter += 1
    if '.' in lan:
        addon.setSetting('onlineserver', lan)
        return [lan]
    addon.setSetting('onlineserver', '192.168.1.40')
    return ['192.168.1.40']

def _get_real_ip():
    """Always returns the real network IP, never 127.0.0.1 - for SMB display."""
    real_ips = getLocalIP()
    for ip in real_ips:
        if not ip.startswith('127.'):
            return ip
    try:
        import socket as _sock
        s = _sock.socket(_sock.AF_INET, _sock.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        pass
    return real_ips[0] if real_ips else '0.0.0.0'

def _resolve_path():
    pathmode   = addon.getSetting('pathmode')
    custompath = addon.getSetting('custompath')
    if pathmode == 'Eigener Pfad' and custompath:
        return custompath
    elif pathmode in ('Kodi Files (Schreibzugriff)', 'Android Data'):
        return '/storage/emulated/0/Android/data/org.xbmc.kodi/files'
    elif pathmode in ('/sdcard', '/sdcard (nur lesen)'):
        return '/sdcard'
    else:
        return xbmcvfs.translatePath('special://home')

def _candidate_ports(port_x_key, port_y_key):
    use_custom  = addon.getSetting(port_x_key) == 'true'
    custom_port = addon.getSetting(port_y_key)
    if use_custom and custom_port and custom_port != '0':
        try:
            return [int(custom_port)]
        except ValueError:
            pass
    return [2121, 2100, 21212, 21000, 21210,
            randint(1024, 65535), randint(1024, 65535)]

class _FtpAuthorizer(DummyAuthorizer):
    def __init__(self, anon, username, password, path):
        super().__init__()
        self._anon = anon
        self._user = username
        if anon:
            self.add_anonymous(path, perm='elradfmwMT')
        else:
            self.add_user(username, password, path, perm='elradfmwMT')

    def validate_authentication(self, username, password, handler):
        if self._anon:
            handler.username = 'anonymous'
        else:
            handler.username = self._user
        super().validate_authentication(handler.username, password, handler)

class FtpThread(threading.Thread):
    def __init__(self, server):
        super().__init__(daemon=True)
        self.server = server

    def run(self):
        try:
            self.server.serve_forever()
        except Exception as e:
            xbmc.log('FTP server error: %r' % e, xbmc.LOGERROR)

def _start_ftp_server(port_x_key, port_y_key):
    global _running_server

    path = _resolve_path()
    if not os.path.exists(path):
        try:
            os.makedirs(path)
        except Exception as e:
            xbmc.log('FTP: Cannot create path %s: %s' % (path, e), xbmc.LOGERROR)

    anon     = addon.getSetting('anonym') == 'true'
    username = addon.getSetting('user') or 'kodi'
    password = addon.getSetting('password') or 'kodi'

    if not anon and (not username or not password):
        if xbmcgui.Dialog().yesno('FTP Server', 'Benutzername/Passwort fehlt. Anonymen Zugang erlauben?'):
            addon.setSetting('anonym', 'true')
            anon = True
        else:
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % ADDON_ID)
            return None, None

    authorizer = _FtpAuthorizer(anon, username, password, path)
    handler = FTPHandler
    handler.authorizer = authorizer
    handler.permit_foreign_addresses = True

    localhost_only = addon.getSetting('localhost_only') == 'true'
    bind_address   = '127.0.0.1' if localhost_only else '0.0.0.0'

    for port in _candidate_ports(port_x_key, port_y_key):
        try:
            server = FTPServer((bind_address, port), handler)
            _running_server = server
            xbmc.log('FTP bound %s:%d' % (bind_address, port), xbmc.LOGINFO)
            return server, port
        except Exception as e:
            xbmc.log('FTP port %d failed: %r' % (port, e), xbmc.LOGWARNING)

    xbmc.log('FTP: no port available', xbmc.LOGERROR)
    return None, None

class FtpWindow(xbmcgui.WindowXML):
    CANCEL_BUTTON_ID = 301
    _own_server = None

    @classmethod
    def create(cls):
        return cls('ftp.xml', variables.addonPath, 'Main', '1080i')

    def onInit(self):
        global _running_smb

        localhost_only = addon.getSetting('localhost_only') == 'true'

        if _svc_get('Started') == 'true':
            if _svc_get('Localhost') == 'true':
                self.setProperty('LocalIP0', '127.0.0.1')
            else:
                i = 0
                while True:
                    ip = _svc_get('LocalIP%d' % i)
                    if not ip:
                        break
                    self.setProperty('LocalIP%d' % i, ip)
                    i += 1
            self.setProperty('Port', _svc_get('Port'))
            self.setProperty('Started', 'true')
            if _svc_get('SmbStarted') == 'true':
                self.setProperty('SmbShare',   _svc_get('SmbShare'))
                self.setProperty('SmbPort',    _svc_get('SmbPort'))
                self.setProperty('SmbStarted', 'true')
                ip = _get_real_ip()
                self.setProperty('SmbDisplay',
                    '\\\\%s:%s\\%s' % (ip, _svc_get('SmbPort'), _svc_get('SmbShare')))
            else:
                smb_enabled, smb_share, smb_port, _, smb_anon, smb_user, smb_pass = _get_smb_settings()
                if smb_enabled:
                    path = _resolve_path()
                    _running_smb = smb_mod.start_smb_server(
                        path, share_name=smb_share, port=smb_port,
                        bind_address='0.0.0.0',
                        anonymous=smb_anon, username=smb_user, password=smb_pass,
                    )
                    if _running_smb:
                        self.setProperty('SmbShare',   smb_share.upper())
                        self.setProperty('SmbPort',    str(smb_port))
                        self.setProperty('SmbStarted', 'true')
                        _svc_set('SmbStarted', 'true')
                        _svc_set('SmbShare',   smb_share.upper())
                        _svc_set('SmbPort',    smb_port)
                        ip = _get_real_ip()
                        self.setProperty('SmbDisplay',
                            '\\\\%s:%d\\%s' % (ip, smb_port, smb_share.upper()))
                    else:
                        self.setProperty('SmbDisplay', 'Fehler beim Start')
                else:
                    self.setProperty('SmbDisplay', 'Deaktiviert')
            return

        ips = ['127.0.0.1'] if localhost_only else getLocalIP()
        for i, ip in enumerate(ips):
            self.setProperty('LocalIP%d' % i, ip)

        path = _resolve_path()
        server, port = _start_ftp_server('portx', 'porty')
        if server is None:
            utils.xbmcNotify('FTP Server', 'Kein Port verfügbar')
            self.close()
            return

        self._own_server = server
        self.setProperty('Port', str(port))
        self.setProperty('Started', 'true')
        FtpThread(server).start()

        _svc_set('Started', 'true')
        _svc_set('Port', port)
        _svc_set('Localhost', 'true' if localhost_only else 'false')
        for i, ip in enumerate(ips):
            _svc_set('LocalIP%d' % i, ip)

        smb_enabled, smb_share, smb_port, _, smb_anon, smb_user, smb_pass = _get_smb_settings()
        if smb_enabled and _svc_get('SmbStarted') != 'true':
            _running_smb = smb_mod.start_smb_server(
                path, share_name=smb_share, port=smb_port,
                bind_address='0.0.0.0',
                anonymous=smb_anon, username=smb_user, password=smb_pass,
            )
            if _running_smb:
                self.setProperty('SmbShare',   smb_share.upper())
                self.setProperty('SmbPort',    str(smb_port))
                self.setProperty('SmbStarted', 'true')
                _svc_set('SmbStarted', 'true')
                _svc_set('SmbShare',   smb_share.upper())
                _svc_set('SmbPort',    smb_port)
                ip = _get_real_ip()
                self.setProperty('SmbDisplay',
                    '\\\\%s:%d\\%s' % (ip, smb_port, smb_share.upper()))
            else:
                self.setProperty('SmbDisplay', 'Deaktiviert')
        elif not smb_enabled:
            self.setProperty('SmbDisplay', 'Deaktiviert')
        elif _svc_get('SmbStarted') == 'true':
            ip = _get_real_ip()
            self.setProperty('SmbDisplay',
                '\\\\%s:%s\\%s' % (ip, _svc_get('SmbPort'), _svc_get('SmbShare')))

    def onClick(self, controlID):
        if controlID == self.CANCEL_BUTTON_ID:
            self.close()

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.close()
        utils.forceWindow.onAction(action)

    def close(self):
        utils.forceWindow.onClose()
        super().close()

    def doModal(self):
        try:
            return super().doModal()
        finally:
            if self._own_server:
                self._own_server.close_all()
                self._own_server = None
                _svc_clear()

def auto():
    global _running_server, _running_smb

    localhost_only = addon.getSetting('localhost_only') == 'true'
    ips = ['127.0.0.1'] if localhost_only else getLocalIP()

    path = _resolve_path()
    server, port = _start_ftp_server('portautox', 'portautoy')
    if server is None:
        xbmc.log('FTP Autostart: kein Port verfügbar', xbmc.LOGERROR)
        return

    addon.setSetting('autostart:port', str(port))
    FtpThread(server).start()

    _svc_set('Started',   'true')
    _svc_set('Port',      port)
    _svc_set('Localhost', 'true' if localhost_only else 'false')
    for i, ip in enumerate(ips):
        _svc_set('LocalIP%d' % i, ip)

    smb_enabled, smb_share, smb_port, smb_autostart, smb_anon, smb_user, smb_pass = _get_smb_settings()
    if smb_enabled and smb_autostart:
        _running_smb = smb_mod.start_smb_server(
            path, share_name=smb_share, port=smb_port,
            bind_address='0.0.0.0',
            anonymous=smb_anon, username=smb_user, password=smb_pass,
        )
        if _running_smb:
            _svc_set('SmbStarted', 'true')
            _svc_set('SmbShare',   smb_share.upper())
            _svc_set('SmbPort',    smb_port)

    try:
        ip_str = ips[0] if ips else '127.0.0.1'
        msg = 'FTP: %s:%d' % (ip_str, port)
        if smb_enabled and smb_autostart and _running_smb:
            msg += '  |  SMB: %s:%d\\%s' % (ip_str, smb_port, smb_share.upper())
        if localhost_only:
            msg += ' (nur lokal)'
        xbmcgui.Dialog().notification('FTP/SMB Server', msg, xbmcgui.NOTIFICATION_INFO, 8000)
        xbmc.log('FTP Autostart OK: %s' % msg, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('FTP Autostart notification error: %s' % e, xbmc.LOGWARNING)

def show():
    variables.assertNotServiceProcess()
    xbmc.executebuiltin('Dialog.Close(all,true)')
    utils.forceWindow.create(FtpWindow)
