import sys
import os

_addon_root = os.path.dirname(os.path.abspath(__file__))
_lib_path = os.path.join(_addon_root, 'lib')
for _p in (_lib_path, _addon_root):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import ftp
ftp.show()
