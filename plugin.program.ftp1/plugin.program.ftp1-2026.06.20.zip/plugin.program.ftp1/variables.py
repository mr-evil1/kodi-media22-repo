import xbmcaddon
import xbmcgui
import xbmc

ADDON_ID = 'plugin.program.ftp1'
addon = xbmcaddon.Addon(ADDON_ID)
addonPath = addon.getAddonInfo('path')
addonVersion = addon.getAddonInfo('version')
WINDOW_HOME = xbmcgui.Window(10000)

IS_SERVICE_PROCESS = False

def assertNotServiceProcess():
    if IS_SERVICE_PROCESS:
        raise RuntimeError('Calling function within the service process')

def localize(id):
    return xbmc.getLocalizedString(id)

def getPlatformName():
    if _isVavooDevice():
        return 'vavoo'
    elif xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'win32'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    else:
        return 'unknown'

def _isVavooDevice():
    if xbmc.getCondVisibility('system.platform.android'):
        try:
            with open('/system/build.prop', 'r') as f:
                content = f.read()
            return 'ro.product.brand=VAVOO' in content and 'ro.vavoo.type=b' in content
        except Exception:
            pass
    return False
