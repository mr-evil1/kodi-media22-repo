import sys
import os
import threading
import socket as _socket
import xbmc
import xbmcaddon
import xbmcgui

AddonID = 'plugin.program.ftp1'
addon   = xbmcaddon.Addon(AddonID)

_addon_root = os.path.dirname(os.path.abspath(__file__))
_lib_path   = os.path.join(_addon_root, 'lib')
for _p in (_lib_path, _addon_root):
    if _p not in sys.path:
        sys.path.insert(0, _p)

def _check_dependencies():
    missing = []
    try:
        import six
    except ImportError:
        missing.append('six')
    try:
        from Cryptodome.Cipher import ARC4
    except ImportError:
        missing.append('pycryptodomex')
    try:
        import pyasn1
    except ImportError:
        missing.append('pyasn1')
    try:
        import pyasn1_modules
    except ImportError:
        missing.append('pyasn1_modules')
    return missing

class SmbThread(threading.Thread):

    def __init__(self, server):
        super(SmbThread, self).__init__()
        self.daemon = True
        self.server = server

    def run(self):
        try:
            self.server.start()
        except Exception as e:
            xbmc.log('SMB Server Thread-Fehler: %r' % e, xbmc.LOGERROR)

def _get_local_ip():
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return _socket.gethostbyname(_socket.gethostname())
        except Exception:
            return '0.0.0.0'

def start_smb_server(path, share_name='KODI', port=4455, bind_address='0.0.0.0',
                     anonymous=True, username='kodi', password='kodi'):
    missing = _check_dependencies()
    if missing:
        msg = 'SMB: Fehlende Bibliotheken: %s' % ', '.join(missing)
        xbmc.log(msg, xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'SMB Server - Fehler',
            msg,
            xbmcgui.NOTIFICATION_ERROR,
            10000,
        )
        return None

    try:
        from impacket.smbserver import SimpleSMBServer
    except ImportError as e:
        xbmc.log('SMB Server: impacket nicht gefunden - %r' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'SMB Server',
            'Fehler: impacket fehlt (lib/impacket)',
            xbmcgui.NOTIFICATION_ERROR,
            10000,
        )
        return None

    try:
        server = SimpleSMBServer(listenAddress=bind_address, listenPort=int(port))
        server.addShare(share_name.upper(), path, '')
        server.setSMB2Support(True)

        if anonymous:

            xbmc.log('SMB Server: Anonymer/Gast-Zugang aktiv (keine Credentials)', xbmc.LOGINFO)
        else:

            server.setSMBChallenge('4b47534d4e4d4353')

            from impacket.ntlm import compute_nthash
            raw = compute_nthash(password)
            nthash_hex = raw.hex() if isinstance(raw, bytes) else raw
            xbmc.log('SMB NT-Hash erzeugt fuer Benutzer: %s (hash len=%d)' % (username, len(nthash_hex)), xbmc.LOGINFO)

            server.addCredential(username.lower(), 0, nthash_hex, nthash_hex)
            xbmc.log('SMB Server: Authentifizierung aktiv, Benutzer: %s' % username, xbmc.LOGINFO)

        _log_file = os.path.join(_addon_root, 'smb_debug.log')
        server.setLogFile(_log_file)
        xbmc.log('SMB debug log: %s' % _log_file, xbmc.LOGINFO)
        SmbThread(server).start()

        local_ip = _get_local_ip()
        smb_address = '\\\\%s:%d\\%s' % (local_ip, int(port), share_name.upper())
        xbmc.log(
            'SMB Server gestartet: %s  pfad=%s  bind=%s'
            % (smb_address, path, bind_address),
            xbmc.LOGINFO,
        )

        addon.setSetting('smb_current_address', smb_address)

        xbmcgui.Dialog().notification(
            'SMB Server gestartet \u2714',
            smb_address,
            xbmcgui.NOTIFICATION_INFO,
            10000,
        )
        return server

    except Exception as e:
        xbmc.log('SMB Server Start fehlgeschlagen: %r' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'SMB Server',
            'Start fehlgeschlagen: %s' % e,
            xbmcgui.NOTIFICATION_ERROR,
            10000,
        )
        return None

def stop_smb_server(server):
    if server is None:
        return
    try:
        server.stop()
        addon.setSetting('smb_current_address', '-')
        xbmc.log('SMB Server gestoppt.', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('SMB Server Stop-Fehler: %r' % e, xbmc.LOGERROR)
