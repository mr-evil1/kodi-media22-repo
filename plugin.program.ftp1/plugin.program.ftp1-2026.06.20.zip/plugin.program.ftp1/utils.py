import xbmc
import xbmcgui
import time
import threading

def humansize(nbytes):
    suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
    if nbytes == 0:
        return '0 B'
    i = 0
    while nbytes >= 1024 and i < len(suffixes) - 1:
        nbytes /= 1024.0
        i += 1
    f = ('%.2f' % nbytes).rstrip('0').rstrip('.')
    return '%s %s' % (f, suffixes[i])

def xbmcNotify(heading, message, icon=xbmcgui.NOTIFICATION_ERROR):
    xbmcgui.Dialog().notification(heading=heading, message=message, icon=icon)

class ForceWindow:
    currentWindow = 0
    last = 0

    def onAction(self, action):
        winId = xbmcgui.getCurrentWindowId()
        if self.currentWindow and self.currentWindow != winId:
            xbmc.executebuiltin('ReplaceWindow(%s)' % self.currentWindow)

    def onClose(self):
        if xbmcgui.getCurrentWindowId() == self.currentWindow:
            self.currentWindow = 0

    def create(self, cls, *args, **kwargs):
        diff = 0.5 - (time.time() - self.last)
        if diff > 0:
            time.sleep(diff)
        self.last = time.time()
        setProperties = kwargs.pop('setProperties', None)
        window = cls.create(*args, **kwargs)
        if setProperties:
            for key, value in setProperties.items():
                window.setProperty(key, value)
        lastWindow = self.showNotModal(window)
        try:
            return window.doModal()
        finally:
            self.closeNotModal(lastWindow)

    def showNotModal(self, window=None):
        lastWindow = self.currentWindow
        if window is not None:
            self.currentWindow = 0
            window.show()
        self.currentWindow = xbmcgui.getCurrentWindowId()
        return lastWindow

    def closeNotModal(self, lastWindow):
        self.currentWindow = lastWindow

forceWindow = ForceWindow()
