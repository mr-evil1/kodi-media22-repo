import sys
import os
import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'plugin.program.ftp1'
addon = xbmcaddon.Addon(ADDON_ID)

_addon_root = os.path.dirname(os.path.abspath(__file__))
_lib_path   = os.path.join(_addon_root, 'lib')
for _p in (_lib_path, _addon_root):
    if _p not in sys.path:
        sys.path.insert(0, _p)

def log(msg, level=xbmc.LOGINFO):
    xbmc.log('plugin.program.ftp1 service: %s' % msg, level)

def _resolve_path():
    pathmode   = addon.getSetting('pathmode')
    custompath = addon.getSetting('custompath')
    if pathmode == 'Eigener Pfad' and custompath:
        return custompath
    elif pathmode in ('Kodi Files (Schreibzugriff)', 'Android Data'):
        home = xbmcvfs.translatePath('special://home')
        android_files = os.path.normpath(os.path.join(home, '..', '..', 'files'))
        if os.path.isdir(android_files):
            return android_files
        return home
    elif pathmode in ('/sdcard', '/sdcard (nur lesen)'):
        return '/sdcard'
    else:
        return xbmcvfs.translatePath('special://home')

def main():
    log('Dienst gestartet.')
    ftp_autostart = addon.getSetting('autostart')     == 'true'
    smb_enabled   = addon.getSetting('smb_enabled')   == 'true'
    smb_autostart = addon.getSetting('smb_autostart') == 'true'

    log('FTP-Autostart: %s  |  SMB aktiv: %s  |  SMB-Autostart: %s'
        % (ftp_autostart, smb_enabled, smb_autostart))

    if ftp_autostart:
        log('Starte FTP-Server (Autostart) …')
        import ftp
        ftp.auto()

        return

    if smb_enabled and smb_autostart:
        log('Starte SMB-Server eigenständig ...')
        import smb_server as smb_mod
        import xbmcgui
        share = addon.getSetting('smb_share') or 'KODI'
        try:
            port = int(addon.getSetting('smb_port') or '4455')
        except ValueError:
            port = 4455
        path     = _resolve_path()
        smb_anon = addon.getSetting('smb_anonymous') != 'false'
        smb_user = addon.getSetting('smb_user') or 'kodi'
        smb_pass = addon.getSetting('smb_password') or 'kodi'
        result = smb_mod.start_smb_server(
            path, share_name=share, port=port,
            bind_address='0.0.0.0',
            anonymous=smb_anon, username=smb_user, password=smb_pass,
        )
        if result:
            _WIN = xbmcgui.Window(10000)
            _WIN.setProperty('FtpSvc_SmbStarted', 'true')
            _WIN.setProperty('FtpSvc_SmbShare',   share.upper())
            _WIN.setProperty('FtpSvc_SmbPort',    str(port))
        log('SMB eigenstandig gestartet: pfad=%s port=%d' % (path, port))

if __name__ == '__main__':
    main()
